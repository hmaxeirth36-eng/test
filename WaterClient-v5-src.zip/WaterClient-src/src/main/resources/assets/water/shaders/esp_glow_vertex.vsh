#version 150

out vec2 texCoord;

void main() {
    vec2 positions[6] = vec2[](
        vec2(0.0, 0.0),
        vec2(1.0, 0.0),
        vec2(1.0, 1.0),
        vec2(0.0, 0.0),
        vec2(1.0, 1.0),
        vec2(0.0, 1.0)
    );
    vec2 pos = positions[gl_VertexID];
    gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
    texCoord = pos;
}
