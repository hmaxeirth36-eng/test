package com.water.mixin;

import com.water.module.modules.render.Freecam;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public class ClientPlayerEntityMixin {
   public ClientPlayerEntityMixin() {
   }

   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void onTickMovement(CallbackInfo ci) {
      if (Freecam.instance != null && Freecam.instance.isEnabled()) {
         ClientPlayerEntity clientPlayerEntity = (ClientPlayerEntity)(Object)this;
         clientPlayerEntity.setSneaking(false);
         clientPlayerEntity.setSprinting(false);
      }
   }
}
